@javax.xml.bind.annotation.XmlSchema(namespace = "http://domain.universal.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.universal.domain;
